# MongoDB M0 document lifecycle 1.0.0

All six native MongoDB activities in one safe run-scoped lifecycle: insert, list collections, find-one/count/distinct, array-filter/update, read-only aggregation and precise deletion. Includes its strict starter schema and a credential-free connection; configure separate credentials or the MONGODB_URI vault secret before running. Sample project

## Sutras

| Sutra | Folder | Starts by | Steps |
|---|---|---|---|
| Sample: MongoDB M0 document lifecycle | Samples/MongoDB | Order input (Manual start) — Payload schema Sample: MongoDB M0 document lifecycle — Order input payload (JSON), Strict schema validation On, Test payload (JSON) {"name":"SutraFlow sample","amount":25} | 11 |

## Project variables

| Name | Type | Value | Description |
|---|---|---|---|
| MONGODB_URI | secret | secret MONGODB_URI | Encrypted complete MongoDB URI. Enter its value in this Secret property, then select it on the sample connection. |

## Connections

| Name | Kind |
|---|---|
| Sample MongoDB M0 | mongodb |

## Sample: MongoDB M0 document lifecycle

MongoDB insert/list collections/read/update/aggregate/delete scoped to one run ID, tested on Atlas M0. Configure separate credentials or a complete URI through Secret properties on the connection, plus database network access. The imported connection selects the MONGODB_URI Secret property by default. No credentials are included.

*Folder Samples/MongoDB, version 1, not deployed*

### How it starts

- Order input (Manual start) — Payload schema Sample: MongoDB M0 document lifecycle — Order input payload (JSON), Strict schema validation On, Test payload (JSON) {"name":"SutraFlow sample","amount":25}

### Steps

| # | Step | Activity | What it does |
|---|---|---|---|
| 1 | Order input | Manual start | Strict input contract is imported with this sample. Supplies only explicit fixture data. |
| 2 | Insert this run order | Insert MongoDB documents | Inserts one document keyed by the current run ID. Configure the connection using separate credentials or a complete-URI secret. |
| 3 | List sample collection | List MongoDB collections | Lists authorized metadata for the sample collection, not its documents. Collection names are selected on each document activity; mapped Collection from input overrides the General value. |
| 4 | Read this run order | Find MongoDB documents | Reads only this run-ID document. BSON types are preserved using Extended JSON. |
| 5 | Count this run order | Find MongoDB documents | Counts only this run-ID document. Expected count=1. Ordinary Find does not implicitly run a total count. |
| 6 | Distinct order name | Find MongoDB documents | Returns one distinct name value for this run-ID document only: SutraFlow sample. |
| 7 | Update this run order | Update MongoDB documents | Updates only this run document. Expected matchedCount=1 and modifiedCount=1. An update modifier is not a full-document schema. |
| 8 | Update selected order line | Update MongoDB documents | Updates only line B and returns the post-update document. Line A remains unchanged. Array filters select repeated nested elements; they do not make a multi-document batch atomic. |
| 9 | Aggregate this run order | Aggregate MongoDB documents | Pipeline is an array of stages: list builds the array, object builds $match, and run.id is shown under $_sutraContext.id. This example queries the selected collection for this run document; it does not aggregate the preceding Update output or calculate a total. Read-only; see the MongoDB guide for $group examples. |
| 10 | Bulk update this run order | Bulk write MongoDB documents | Sends two updates of this run-ID document in one request (ordered). Expected matchedCount=2 and modifiedCount=2. A bulk write may mix insertOne, updateOne/updateMany, replaceOne and deleteOne/deleteMany; any failing operation fails the step with the counts written so far. |
| 11 | Delete this run order | Delete MongoDB documents | Intentional sample cleanup: deletes only this run-ID document, so the collection may be empty after success. Inspect the document before this step, or omit this step in a copy for inspection and clean up your run ID afterwards. Never delete a whole user collection. |

#### 1. Order input (Manual start)

Strict input contract is imported with this sample. Supplies only explicit fixture data.

| Setting | Value |
|---|---|
| Payload schema | Sample: MongoDB M0 document lifecycle — Order input payload (JSON) |
| Strict schema validation | On |
| Test payload (JSON) | {"name":"SutraFlow sample","amount":25} |

Next: Insert this run order (Insert MongoDB documents).

#### 2. Insert this run order (Insert MongoDB documents)

Inserts one document keyed by the current run ID. Configure the connection using separate credentials or a complete-URI secret.

| Setting | Value |
|---|---|
| MongoDB connection | Sample MongoDB M0 (mongodb) |
| Collection | sutraflow_sample_orders |
| Collection from input (optional override) (default) | (not set) |
| Document or document list | =object('_id', {run.id}, 'name', {input.name}, 'amount', {input.amount}, 'lines', list(object('sku', 'A', 'quantity', 1), object('sku', 'B', 'quantity', 2))) |
| Stop batch on first server error | On |
| Input document schema (default) | (not set) |
| Strict schema validation (default) | Off |

Next: List sample collection (List MongoDB collections).

#### 3. List sample collection (List MongoDB collections)

Lists authorized metadata for the sample collection, not its documents. Collection names are selected on each document activity; mapped Collection from input overrides the General value.

| Setting | Value |
|---|---|
| MongoDB connection | Sample MongoDB M0 (mongodb) |
| Filter (JSON / Extended JSON) | {"name":"sutraflow_sample_orders"} |
| Collection metadata schema (default) | (not set) |
| Strict schema validation (default) | Off |

Next: Read this run order (Find MongoDB documents).

#### 4. Read this run order (Find MongoDB documents)

Reads only this run-ID document. BSON types are preserved using Extended JSON.

| Setting | Value |
|---|---|
| MongoDB connection | Sample MongoDB M0 (mongodb) |
| Collection | sutraflow_sample_orders |
| Collection from input (optional override) (default) | (not set) |
| Operation | findOne |
| Filter (JSON / Extended JSON) | =object('_id', {run.id}) |
| Projection (default) | {} |
| Sort (default) | {} |
| Skip (default) | 0 |
| Runtime limit (0 = no query limit) (default) | 0 |
| Distinct field (default) (inactive) | (not set) |
| Returned document/value schema (default) | (not set) |
| Strict schema validation (default) | Off |

Next: Count this run order (Find MongoDB documents).

#### 5. Count this run order (Find MongoDB documents)

Counts only this run-ID document. Expected count=1. Ordinary Find does not implicitly run a total count.

| Setting | Value |
|---|---|
| MongoDB connection | Sample MongoDB M0 (mongodb) |
| Collection | sutraflow_sample_orders |
| Collection from input (optional override) (default) | (not set) |
| Operation | count |
| Filter (JSON / Extended JSON) | =object('_id', {run.id}) |
| Projection (default) | {} |
| Sort (default) | {} |
| Skip (default) | 0 |
| Runtime limit (0 = no query limit) (default) | 0 |
| Distinct field (default) (inactive) | (not set) |
| Returned document/value schema (default) | (not set) |
| Strict schema validation (default) | Off |

Next: Distinct order name (Find MongoDB documents).

#### 6. Distinct order name (Find MongoDB documents)

Returns one distinct name value for this run-ID document only: SutraFlow sample.

| Setting | Value |
|---|---|
| MongoDB connection | Sample MongoDB M0 (mongodb) |
| Collection | sutraflow_sample_orders |
| Collection from input (optional override) (default) | (not set) |
| Operation | distinct |
| Filter (JSON / Extended JSON) | =object('_id', {run.id}) |
| Projection (default) | {} |
| Sort (default) | {} |
| Skip (default) | 0 |
| Runtime limit (0 = no query limit) (default) | 0 |
| Distinct field | name |
| Returned document/value schema (default) | (not set) |
| Strict schema validation (default) | Off |

Next: Update this run order (Update MongoDB documents).

#### 7. Update this run order (Update MongoDB documents)

Updates only this run document. Expected matchedCount=1 and modifiedCount=1. An update modifier is not a full-document schema.

| Setting | Value |
|---|---|
| MongoDB connection | Sample MongoDB M0 (mongodb) |
| Collection | sutraflow_sample_orders |
| Collection from input (optional override) (default) | (not set) |
| Filter (JSON / Extended JSON) | =object('_id', {run.id}) |
| Operation | updateOne |
| Update operators or replacement | {"$set":{"status":"processed"}} |
| Array filters (optional JSON array) (default) | [] |
| Returned document (default) (inactive) | after |
| Insert when not found (default) | Off |
| Allow empty filter for updateMany (default) | Off |
| Update request / replacement schema (default) | (not set) |
| Strict schema validation (default) | Off |

Next: Update selected order line (Update MongoDB documents).

#### 8. Update selected order line (Update MongoDB documents)

Updates only line B and returns the post-update document. Line A remains unchanged. Array filters select repeated nested elements; they do not make a multi-document batch atomic.

| Setting | Value |
|---|---|
| MongoDB connection | Sample MongoDB M0 (mongodb) |
| Collection | sutraflow_sample_orders |
| Collection from input (optional override) (default) | (not set) |
| Filter (JSON / Extended JSON) | =object('_id', {run.id}) |
| Operation | findOneAndUpdate |
| Update operators or replacement | {"$set":{"lines.$[line].quantity":9}} |
| Array filters (optional JSON array) | [{"line.sku":"B"}] |
| Returned document | after |
| Insert when not found (default) | Off |
| Allow empty filter for updateMany (default) | Off |
| Update request / replacement schema (default) | (not set) |
| Strict schema validation (default) | Off |

Next: Aggregate this run order (Aggregate MongoDB documents).

#### 9. Aggregate this run order (Aggregate MongoDB documents)

Pipeline is an array of stages: list builds the array, object builds $match, and run.id is shown under $_sutraContext.id. This example queries the selected collection for this run document; it does not aggregate the preceding Update output or calculate a total. Read-only; see the MongoDB guide for $group examples.

| Setting | Value |
|---|---|
| MongoDB connection | Sample MongoDB M0 (mongodb) |
| Collection | sutraflow_sample_orders |
| Collection from input (optional override) (default) | (not set) |
| Pipeline (JSON array) | =list(object('$match', object('_id', {run.id}))) |
| Allow disk use (default) | Off |
| Allow output stages ($merge / $out) (default) | Off |
| Result document schema (default) | (not set) |
| Strict schema validation (default) | Off |

Next: Bulk update this run order (Bulk write MongoDB documents).

#### 10. Bulk update this run order (Bulk write MongoDB documents)

Sends two updates of this run-ID document in one request (ordered). Expected matchedCount=2 and modifiedCount=2. A bulk write may mix insertOne, updateOne/updateMany, replaceOne and deleteOne/deleteMany; any failing operation fails the step with the counts written so far.

| Setting | Value |
|---|---|
| MongoDB connection | Sample MongoDB M0 (mongodb) |
| Collection | sutraflow_sample_orders |
| Collection from input (optional override) (default) | (not set) |
| Operations (JSON array) | =list(object('updateOne', object('filter', object('_id', {run.id}), 'update', object('$set', object('reviewed', true)))), object('updateOne', object('filter', object('_id', {run.id}), 'update', object('$inc', object('amount', 1))))) |
| Ordered (stop at the first failing operation) | On |
| Allow empty filter for updateMany/deleteMany (default) | Off |
| Inserted/replacement document schema (default) | (not set) |
| Strict schema validation (default) | Off |

Next: Delete this run order (Delete MongoDB documents).

#### 11. Delete this run order (Delete MongoDB documents)

Intentional sample cleanup: deletes only this run-ID document, so the collection may be empty after success. Inspect the document before this step, or omit this step in a copy for inspection and clean up your run ID afterwards. Never delete a whole user collection.

| Setting | Value |
|---|---|
| MongoDB connection | Sample MongoDB M0 (mongodb) |
| Collection | sutraflow_sample_orders |
| Collection from input (optional override) (default) | (not set) |
| Filter (JSON / Extended JSON) | =object('_id', {run.id}) |
| Delete all matches | Off |
| Allow empty filter for delete-many (default) | Off |
| Filter request schema (default) | (not set) |
| Strict schema validation (default) | Off |

Next: the run ends here.

### Connections

- Sample MongoDB M0 (mongodb)
