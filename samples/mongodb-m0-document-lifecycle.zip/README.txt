SutraFlow release MongoDB M0 document lifecycle 1.0.0

Sample project

Made 2026-11-03T12:19:55.284Z with SutraFlow 2.1.5. Checksum sha256:424409379c3cbeb93ad0d96b677fd046aa949ed67166bb1f98a2b894dc438300.

Contents
  package.sutra            the package: 1 Sutras, 1 connections, 1 schemas
  deployment-config.json   the deployment config: fill it in for the target environment
  documentation.html       what each Sutra does, step by step (also documentation.md)

Sutras
  Sample: MongoDB M0 document lifecycle v1

Secrets the target server needs in its vault
  MONGODB_URI

Deploying
  1. Add the secrets:   sutra secret set NAME --from-env NAME --server https://prod:4800 --token ...
  2. Edit deployment-config.json for this environment (hosts, folders, users, secret names).
  3. Check:             sutra check release.zip --server https://prod:4800 --token ...
  4. Deploy:            sutra deploy release.zip --server https://prod:4800 --token ...
     or upload the zip in the Admin Console under Releases.
  Roll back:            sutra rollback --project "MongoDB M0 document lifecycle" --server ... --token ...
