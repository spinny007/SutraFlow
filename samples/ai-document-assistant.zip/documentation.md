# AI document assistant 1.0.0

RAG over a folder of documents: every 15 minutes the PDF, Word, PowerPoint and Markdown files of the documents folder are read into a knowledge base (changed files again, deleted ones removed), and the documents answer as a REST API, an MCP tool for AI assistants such as Claude, and a chat agent. Sample documents of a tea shop are included. Sample project

## Sutras

| Sutra | Folder | Starts by | Steps |
|---|---|---|---|
| Sample: Add one document to knowledge | Samples/AI agents | File (Manual start) — Payload schema Sample: Add one document to knowledge — File payload (JSON), Test payload (JSON) {   "name": "returns-policy.pdf",   "relativePath": "returns-policy.pdf",   "extension": "pdf",   "size": 3201,   "modifiedAt": "2026-10-19T09:00:00.000Z" } | 9 |
| Sample: AI tool search documents | Samples/AI agents | search_documents (AI tool) — MCP server (default) (not set), Tool name search_documents, Title Search documents | 4 |
| Sample: Document assistant | Samples/AI agents | Document assistant (Agent channel) — Agent name docs-assistant, Title Document assistant, What it does (for people and other AIs) Answers questions about Asha Traders returns, shipping, products and payments from the shop documents, with sources. | 4 |
| Sample: Document feed from a folder | Samples/AI agents | Every 15 minutes (Timer) — Schedule by cron, Cron expression 0 */15 * * * *, Every (seconds) (inactive) 900 | 7 |
| Sample: Document questions API | Samples/AI agents | Ask API (REST service) — Method POST, Path /samples/docs/ask, API security policy (not set) | 5 |

## Project variables

| Name | Type | Value | Description |
|---|---|---|---|
| DOCS_FOLDER | string | ${files}/documents | Folder of documents the knowledge base is fed from (PDF, Word, PowerPoint, Excel, OpenDocument, HTML, text, Markdown). ${files} is the project files folder; use any folder of this server instead. |

## Connections

| Name | Kind |
|---|---|
| Sample document knowledge base | aiKnowledge |
| Sample AI memory | aiMemory |
| Local Ollama | aiProvider |

## Sample: Add one document to knowledge

Called once per file by "Sample: Document feed from a folder": reads the file, takes its text and adds it to the knowledge base under its path in the folder. A file whose text has not changed since the last feed is skipped, so no vectors are made again. Files of other types are left alone; a file that cannot be read is logged and the feed goes on.

*Folder Samples/AI agents, version 1, not deployed*

### How it starts

- File (Manual start) — Payload schema Sample: Add one document to knowledge — File payload (JSON), Test payload (JSON) {
  "name": "returns-policy.pdf",
  "relativePath": "returns-policy.pdf",
  "extension": "pdf",
  "size": 3201,
  "modifiedAt": "2026-10-19T09:00:00.000Z"
}

### Steps

| # | Step | Activity | What it does |
|---|---|---|---|
| 1 | File | Manual start | One file from the folder listing: name, path in the folder, extension, size and time changed. The test data is the sample returns policy. |
| 2 | Document type | If / else | Only file types Read document text understands go on; anything else (pictures, zips) is skipped. |
| 3 | Read the file | Read file | Reads the file from the documents folder (project variable DOCS_FOLDER) as base64, because documents are binary. |
| 4 | Log other file | Log | Notes files that are not documents, for the run history. |
| 5 | Take the text | Read document text | Takes the text out of the document: PDF pages, Word paragraphs, PowerPoint slides, Excel sheets, HTML or plain text. The extension tells the type. |
| 6 | Log not added | Log | A damaged, empty or protected file is logged as a warning; the feed carries on with the next file. |
| 7 | Return left out | Return | Returns the file as it came, so the feed counts it as left out. |
| 8 | Add to knowledge | Add to knowledge | Splits the text into passages, makes their vectors and stores them under the file's path, with its type and title as details. Same text as before: skipped. |
| 9 | Return added | Return | Gives the feed what was done: source, passages, and whether it was skipped as unchanged. |

#### 1. File (Manual start)

One file from the folder listing: name, path in the folder, extension, size and time changed. The test data is the sample returns policy.

| Setting | Value |
|---|---|
| Payload schema | Sample: Add one document to knowledge — File payload (JSON) |
| Test payload (JSON) | {   "name": "returns-policy.pdf",   "relativePath": "returns-policy.pdf",   "extension": "pdf",   "size": 3201,   "modifiedAt": "2026-10-19T09:00:00.000Z" } |

Next: Document type (If / else).

#### 2. Document type (If / else)

Only file types Read document text understands go on; anything else (pictures, zips) is skipped.

| Setting | Value |
|---|---|
| Value | =lower-case({trigger.extension}) |
| Check | matches regex |
| Compare to | ^(pdf\|docx\|pptx\|xlsx\|odt\|odp\|ods\|html\|htm\|txt\|md\|csv)$ |

Next: true: Read the file (Read file); false: Log other file (Log).

#### 3. Read the file (Read file)

Reads the file from the documents folder (project variable DOCS_FOLDER) as base64, because documents are binary.

| Setting | Value |
|---|---|
| Folder | {{gv.DOCS_FOLDER}} |
| File (relative to the folder) | {{trigger.relativePath}} |
| Read content as | base64 (binary) |
| File encoding (default) (inactive) | utf-8 |
| Column separator (default) (inactive) | , |
| First row has column names (default) (inactive) | On |
| Skip rows at the start (default) (inactive) | 0 |
| Trim spaces around values (default) (inactive) | On |
| Decimal separator (default) (inactive) | . |
| Strict schema validation (default) (inactive) | Off |
| Row / data schema (default) (inactive) | (not set) |
| Stream in batches (default) (inactive) | Off |
| Rows per batch (default) (inactive) | 1000 |
| Maximum size (MB) | 25 |

Next: Take the text (Read document text); error: Log not added (Log).
Errors: handled by the error branch.

#### 4. Log other file (Log)

Notes files that are not documents, for the run history.

| Setting | Value |
|---|---|
| Message | Not a document type, left out: {{trigger.relativePath}} |
| Level | info |

Next: Return left out (Return).

#### 5. Take the text (Read document text)

Takes the text out of the document: PDF pages, Word paragraphs, PowerPoint slides, Excel sheets, HTML or plain text. The extension tells the type.

| Setting | Value |
|---|---|
| Document from | earlier step |
| Content | {{input.content}} |
| Content is | base64 |
| File name | {{trigger.name}} |
| Web address (default) (inactive) | https://www.example.com/returns |
| Type | auto |
| Maximum size (MB) | 25 |

Next: Add to knowledge (Add to knowledge); error: Log not added (Log).
Errors: handled by the error branch.

#### 6. Log not added (Log)

A damaged, empty or protected file is logged as a warning; the feed carries on with the next file.

| Setting | Value |
|---|---|
| Message | Not added: {{trigger.relativePath}}: {{input.error.message}} |
| Level | warn |

Next: Return left out (Return).

#### 7. Return left out (Return)

Returns the file as it came, so the feed counts it as left out.

| Setting | Value |
|---|---|
| Result from | value |
| Result | {{trigger}} |
| Result schema (default) (inactive) | (not set) |
| Result (default) (inactive) | {"rules":{}} |

Next: the run ends here.

#### 8. Add to knowledge (Add to knowledge)

Splits the text into passages, makes their vectors and stores them under the file's path, with its type and title as details. Same text as before: skipped.

| Setting | Value |
|---|---|
| Knowledge base | Sample document knowledge base (aiKnowledge) |
| Source name | {{trigger.relativePath}} |
| Text | {{input.text}} |
| Details | [{"k":"type","v":"{{trigger.extension}}"},{"k":"title","v":"{{input.title}}"}] |
| Same text as before | skip |

Next: Return added (Return); error: Log not added (Log).
Errors: handled by the error branch.

#### 9. Return added (Return)

Gives the feed what was done: source, passages, and whether it was skipped as unchanged.

| Setting | Value |
|---|---|
| Result from | value |
| Result | {{input}} |
| Result schema (default) (inactive) | (not set) |
| Result (default) (inactive) | {"rules":{}} |

Next: the run ends here.

### Connections

- Sample document knowledge base (aiKnowledge)

### Variables

Project variables used: DOCS_FOLDER.

## Sample: AI tool search documents

An AI tool: while deployed, AI assistants such as Claude Desktop call search_documents over MCP at http://127.0.0.1:8080/mcp and get the passages of the documents closest to their question, with sources; agents of this project can use it too. No AI model is needed on this server: the assistant writes the answer.

*Folder Samples/AI agents, version 1, not deployed*

### How it starts

- search_documents (AI tool) — MCP server (default) (not set), Tool name search_documents, Title Search documents

### Steps

| # | Step | Activity | What it does |
|---|---|---|---|
| 1 | search_documents | AI tool | Makes this Sutra the MCP tool search_documents with one input, question. |
| 2 | Search documents | Search knowledge | Finds the five passages closest to the question by meaning and shared words. |
| 3 | Reply with passages | Reply to AI | Returns the passages with their sources and scores to the AI assistant. |
| 4 | Reply nothing found | Reply to AI | Tells the assistant plainly that the documents hold nothing about it. |

#### 1. search_documents (AI tool)

Makes this Sutra the MCP tool search_documents with one input, question.

| Setting | Value |
|---|---|
| MCP server (default) | (not set) |
| Tool name | search_documents |
| Title | Search documents |
| What it does (for the AI) | Searches the Asha Traders policy and product documents (returns, shipping, catalogue, FAQ) and returns the passages closest to the question, with the document each comes from. |
| Inputs | [{"k":"question","v":"What to look for, in plain words"}] |
| Input schema (instead of the rows) (default) | (not set) |
| Result schema (default) | (not set) |
| AI agents of this project may use it | On |
| Changes data (not read-only) | Off |
| API security policy (default) | (not set) |
| Test arguments (JSON) | {   "question": "Which tea is best for milk tea?" } |

Next: Search documents (Search knowledge).

#### 2. Search documents (Search knowledge)

Finds the five passages closest to the question by meaning and shared words.

| Setting | Value |
|---|---|
| Knowledge base | Sample document knowledge base (aiKnowledge) |
| Question | {{input.arguments.question}} |
| Passages | 5 |
| Minimum score (0 to 1) (default) | 0.05 |
| Only from source (default) | (not set) |
| Only with details (default) | [] |

Next: Reply with passages (Reply to AI); empty: Reply nothing found (Reply to AI).

#### 3. Reply with passages (Reply to AI)

Returns the passages with their sources and scores to the AI assistant.

| Setting | Value |
|---|---|
| Result from | value |
| Result | {{input.hits}} |
| Result schema (default) (inactive) | (not set) |
| Result (default) (inactive) | {"rules":{}} |
| Is an error | Off |

Next: the run ends here.

#### 4. Reply nothing found (Reply to AI)

Tells the assistant plainly that the documents hold nothing about it.

| Setting | Value |
|---|---|
| Result from | value |
| Result | Nothing in the documents matches that question. |
| Result schema (default) (inactive) | (not set) |
| Result (default) (inactive) | {"rules":{}} |
| Is an error | Off |

Next: the run ends here.

### Connections

- Sample document knowledge base (aiKnowledge)

## Sample: Document assistant

Published as the agent "docs-assistant": chat at http://127.0.0.1:8080/chat/docs-assistant, OpenAI-compatible model docs-assistant at http://127.0.0.1:8080/v1/chat/completions, and the MCP tool ask_docs_assistant at http://127.0.0.1:8080/mcp. The agent searches the documents itself (search_knowledge), remembers each conversation, and answers with the document names.

*Folder Samples/AI agents, version 1, not deployed*

### How it starts

- Document assistant (Agent channel) — Agent name docs-assistant, Title Document assistant, What it does (for people and other AIs) Answers questions about Asha Traders returns, shipping, products and payments from the shop documents, with sources.

### Steps

| # | Step | Activity | What it does |
|---|---|---|---|
| 1 | Document assistant | Agent channel | Publishes the agent as a chat page, an OpenAI-compatible model and an MCP tool, all at the gateway. |
| 2 | Document agent | AI agent | The agent: gets the three closest passages before it starts, may search again with search_knowledge, and remembers the conversation by session. |
| 3 | Reply | Agent reply | Sends the answer back on the channel the question came from. |
| 4 | Reply limit | Agent reply | The agent used up its steps or time: a polite answer instead of silence. |

#### 1. Document assistant (Agent channel)

Publishes the agent as a chat page, an OpenAI-compatible model and an MCP tool, all at the gateway.

| Setting | Value |
|---|---|
| Agent name | docs-assistant |
| Title | Document assistant |
| What it does (for people and other AIs) | Answers questions about Asha Traders returns, shipping, products and payments from the shop documents, with sources. |
| Chat page and chat API | On |
| Who may chat (default) | (not set) |
| OpenAI-compatible API | On |
| Who may use the API (default) | (not set) |
| Tool on an MCP server | On |
| MCP server | (not set) |
| Agent-to-agent (A2A) | Off |
| Who may call it (default) (inactive) | (not set) |
| Answer within (seconds) | 50 |
| Test message (JSON) | {   "message": "How long does delivery to Mumbai take, and is shipping free?",   "sessionId": "test-1" } |

Next: Document agent (AI agent).

#### 2. Document agent (AI agent)

The agent: gets the three closest passages before it starts, may search again with search_knowledge, and remembers the conversation by session.

| Setting | Value |
|---|---|
| AI provider | Local Ollama (aiProvider) |
| Instructions | You answer questions about Asha Traders (a tea and crockery shop in Pune) from its documents. Always search the knowledge base first; answer in two to four sentences from what you find, and name the documents you used. If the documents do not say, say so; never guess prices, times or rules. |
| Message or goal | {{input.message}} |
| AI memory store | Sample AI memory (aiMemory) |
| Session id | {{trigger.sessionId}} |
| Tools | none |
| Tool names (default) (inactive) | (not set) |
| Knowledge base | Sample document knowledge base (aiKnowledge) |
| Passages fetched before the first step | 3 |
| MCP client (outside tools) (default) | (not set) |
| May ask a person | Off |
| Answer as | text |
| Maximum steps | 5 |
| Maximum tokens | 30000 |
| Maximum time (seconds) | 300 |
| Context window without memory (tokens) (default) | 8000 |
| Keep tool results in memory | On |
| Effort | low |

Next: done: Reply (Agent reply); limit reached: Reply limit (Agent reply); needs a person: Reply limit (Agent reply).

#### 3. Reply (Agent reply)

Sends the answer back on the channel the question came from.

| Setting | Value |
|---|---|
| Answer | {{input.answer}} |
| Status | answer |
| Session id | {{trigger.sessionId}} |

Next: the run ends here.

#### 4. Reply limit (Agent reply)

The agent used up its steps or time: a polite answer instead of silence.

| Setting | Value |
|---|---|
| Answer | I could not finish that. Please ask the order desk. |
| Status | needs a person |
| Session id | {{trigger.sessionId}} |

Next: the run ends here.

### Connections

- Sample document knowledge base (aiKnowledge)
- Sample AI memory (aiMemory)
- Local Ollama (aiProvider)

## Sample: Document feed from a folder

Every 15 minutes, lists the documents folder (project variable DOCS_FOLDER, with sub-folders) and calls "Sample: Add one document to knowledge" for each file, so new and changed files reach the knowledge base; then removes from it the files that were deleted from the folder. Test it once to fill the knowledge base; deploy it (and the called Sutra) to keep it up to date.

*Folder Samples/AI agents, version 1, not deployed*

### How it starts

- Every 15 minutes (Timer) — Schedule by cron, Cron expression 0 */15 * * * *, Every (seconds) (inactive) 900

### Steps

| # | Step | Activity | What it does |
|---|---|---|---|
| 1 | Every 15 minutes | Timer | Starts the feed every 15 minutes while deployed. Choose a longer time for large folders; Test runs it at once. |
| 2 | List documents | List / read directory | Lists every file in the documents folder and its sub-folders, without reading them: name, path in the folder, extension, size, time changed. |
| 3 | Each file | For each | Sends every file of the listing down the item branch, then the whole list down the done branch. |
| 4 | Folder is empty | Log | Warns when the folder is empty or missing, for example when DOCS_FOLDER points to the wrong place on this server. |
| 5 | Add the document | Call Sutra | Calls "Add one document to knowledge" with the file, and waits for it. Keeping the work for one file in its own Sutra lets every step there refer to the file as {trigger}. |
| 6 | Remove deleted files | Remove knowledge | Keeps only the sources that are still files in the folder: documents deleted from the folder leave the knowledge base too. |
| 7 | Log the feed | Log | Writes a summary line to the run history and the project log. |

#### 1. Every 15 minutes (Timer)

Starts the feed every 15 minutes while deployed. Choose a longer time for large folders; Test runs it at once.

| Setting | Value |
|---|---|
| Schedule by | cron |
| Cron expression | 0 */15 * * * * |
| Every (seconds) (inactive) | 900 |
| Time zone | Asia/Kolkata |
| Payload (JSON) | {} |

Next: List documents (List / read directory).

#### 2. List documents (List / read directory)

Lists every file in the documents folder and its sub-folders, without reading them: name, path in the folder, extension, size, time changed.

| Setting | Value |
|---|---|
| Location | {{gv.DOCS_FOLDER}} |
| Pattern (when the location is a folder) | * |
| Include sub-folders | On |
| Order | name |
| Maximum files | 2000 |
| Read content as | do not read |
| File encoding (default) (inactive) | utf-8 |
| Column separator (default) (inactive) | , |
| First row has column names (default) (inactive) | On |
| Skip rows at the start (default) (inactive) | 0 |
| Trim spaces around values (default) (inactive) | On |
| Decimal separator (default) (inactive) | . |
| Strict schema validation (default) (inactive) | Off |
| Row / data schema (default) (inactive) | (not set) |
| Stream in batches (default) (inactive) | Off |
| Rows per batch (default) (inactive) | 1000 |

Next: Each file (For each); empty: Folder is empty (Log).

#### 3. Each file (For each)

Sends every file of the listing down the item branch, then the whole list down the done branch.

| Setting | Value |
|---|---|
| List | {{input.files}} |
| Maximum items | 2000 |

Next: item: Add the document (Call Sutra); done: Remove deleted files (Remove knowledge).

#### 4. Folder is empty (Log)

Warns when the folder is empty or missing, for example when DOCS_FOLDER points to the wrong place on this server.

| Setting | Value |
|---|---|
| Message | No files in {{gv.DOCS_FOLDER}} |
| Level | warn |

Next: the run ends here.

#### 5. Add the document (Call Sutra)

Calls "Add one document to knowledge" with the file, and waits for it. Keeping the work for one file in its own Sutra lets every step there refer to the file as {trigger}.

| Setting | Value |
|---|---|
| Sutra | Sample: Add one document to knowledge |
| Version | deployed (draft while testing) |
| Wait for the result | On |
| Input from | value |
| Input | {{input}} |
| Input schema (default) (inactive) | (not set) |
| Input (default) (inactive) | {"rules":{}} |
| Result schema | (not set) |

Next: the run ends here.

#### 6. Remove deleted files (Remove knowledge)

Keeps only the sources that are still files in the folder: documents deleted from the folder leave the knowledge base too.

| Setting | Value |
|---|---|
| Knowledge base | Sample document knowledge base (aiKnowledge) |
| Action | keep only these sources |
| Source name (default) (inactive) | {{input.name}} |
| Sources to keep | {{input.items}} |
| Only in the folder of sources | (not set) |

Next: Log the feed (Log).

#### 7. Log the feed (Log)

Writes a summary line to the run history and the project log.

| Setting | Value |
|---|---|
| Message | =concat(count({nodes.List documents.files}), ' files checked; ', {input.removed}, ' deleted files removed from the knowledge base') |
| Level | info |

Next: the run ends here.

### Connections

- Sample document knowledge base (aiKnowledge)

### Variables

Project variables used: DOCS_FOLDER.

## Sample: Document questions API

A REST API over the documents: POST http://127.0.0.1:8080/samples/docs/ask with {"question": "..."} answers from the knowledge base with the documents it used, or 404 when the documents do not say. Run the document feed first.

*Folder Samples/AI agents, version 1, not deployed*

### How it starts

- Ask API (REST service) — Method POST, Path /samples/docs/ask, API security policy (not set)

### Steps

| # | Step | Activity | What it does |
|---|---|---|---|
| 1 | Ask API | REST service | Receives the question as JSON. Give it an API security policy before exposing it outside your network. |
| 2 | Answer from documents | Ask knowledge | Searches the knowledge base for the four closest passages and lets the AI answer only from them, with their sources. Goes to "not found" when nothing matches. |
| 3 | Reply 200 | Send HTTP response | Sends the answer and the documents it came from. |
| 4 | Reply 404 | Send HTTP response | The documents hold nothing about the question: says so instead of guessing. |
| 5 | Reply 502 | Send HTTP response | The AI model could not be reached (is Ollama running, with a model chosen in the Local Ollama connection?). |

#### 1. Ask API (REST service)

Receives the question as JSON. Give it an API security policy before exposing it outside your network.

| Setting | Value |
|---|---|
| Method | POST |
| Path | /samples/docs/ask |
| API security policy | (not set) |
| Max body size (KB) | 16 |
| Required scopes (default) | (not set) |
| Request body schema | (not set) |
| Validate requests (default) | off |
| Test request (JSON) | {   "method": "POST",   "params": {},   "query": {},   "headers": {},   "body": {     "question": "How many days do I have to return an item?"   } } |

Next: Answer from documents (Ask knowledge).

#### 2. Answer from documents (Ask knowledge)

Searches the knowledge base for the four closest passages and lets the AI answer only from them, with their sources. Goes to "not found" when nothing matches.

| Setting | Value |
|---|---|
| AI provider | Local Ollama (aiProvider) |
| Knowledge base | Sample document knowledge base (aiKnowledge) |
| Question | {{input.body.question}} |
| Passages | 4 |
| Instructions | Answer in two or three sentences, only from the passages, in the language of the question. Name the document you used. |
| Only with details (default) | [] |
| Effort | low |

Next: Reply 200 (Send HTTP response); not found: Reply 404 (Send HTTP response); error: Reply 502 (Send HTTP response).
Errors: handled by the error branch.

#### 3. Reply 200 (Send HTTP response)

Sends the answer and the documents it came from.

| Setting | Value |
|---|---|
| Status code | 200 |
| Content type | application/json |
| Build body from | template |
| Body | {"answer": {{input.answer \| json}}, "sources": {{input.sources \| json}}} |
| Body schema (default) | (not set) |
| Response body (default) (inactive) | {"rules":{}} |
| Headers | [] |

Next: the run ends here.

#### 4. Reply 404 (Send HTTP response)

The documents hold nothing about the question: says so instead of guessing.

| Setting | Value |
|---|---|
| Status code | 404 |
| Content type | application/json |
| Build body from | template |
| Body | {"answer": "The documents do not say.", "sources": []} |
| Body schema (default) | (not set) |
| Response body (default) (inactive) | {"rules":{}} |
| Headers | [] |

Next: the run ends here.

#### 5. Reply 502 (Send HTTP response)

The AI model could not be reached (is Ollama running, with a model chosen in the Local Ollama connection?).

| Setting | Value |
|---|---|
| Status code | 502 |
| Content type | application/json |
| Build body from | template |
| Body | {"error": {{input.error.message \| json}}} |
| Body schema (default) | (not set) |
| Response body (default) (inactive) | {"rules":{}} |
| Headers | [] |

Next: the run ends here.

### Connections

- Sample document knowledge base (aiKnowledge)
- Local Ollama (aiProvider)
