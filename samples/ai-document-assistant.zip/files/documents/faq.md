# Order desk FAQ

## Can I change my delivery address?
Yes, until the order leaves the warehouse. Write to the order desk with the order number and the new address.

## Do you sell wholesale?
Cafes and shops can buy in bulk from 10 kg of tea or 60 cups, with 15 percent off the list price. Ask the order desk for a quote.

## Which tea is best for milk tea?
Assam tea (TEA-01) or the masala chai blend (CHAI-03). Darjeeling is best without milk.

## How do I pay?
UPI, cards, net banking, or cash on delivery for orders up to Rs. 5,000.
