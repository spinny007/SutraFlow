SutraFlow release AI document assistant 1.0.0

Sample project

Made 2026-10-24T07:25:25.476Z with SutraFlow 2.0.8. Checksum sha256:1b36901b6d506af3234d49408797572624d5d33fc6c2fb4bd17536eef9243192.

Contents
  package.sutra            the package: 5 Sutras, 3 connections, 1 schemas
  deployment-config.json   the deployment config: fill it in for the target environment
  documentation.html       what each Sutra does, step by step (also documentation.md)

Sutras
  Sample: AI tool search documents v1
  Sample: Add one document to knowledge v1
  Sample: Document assistant v1
  Sample: Document feed from a folder v1
  Sample: Document questions API v1

Secrets the target server needs in its vault
  none

Deploying
  1. Add the secrets:   sutra secret set NAME --from-env NAME --server https://prod:4800 --token ...
  2. Edit deployment-config.json for this environment (hosts, folders, users, secret names).
  3. Check:             sutra check release.zip --server https://prod:4800 --token ...
  4. Deploy:            sutra deploy release.zip --server https://prod:4800 --token ...
     or upload the zip in the Admin Console under Releases.
  Roll back:            sutra rollback --project "AI document assistant" --server ... --token ...
