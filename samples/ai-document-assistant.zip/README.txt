SutraFlow release AI document assistant 1.0.0

Sample project

Made 2026-10-22T07:17:28.603Z with SutraFlow 2.0.0. Checksum sha256:00371ef74fee2e52bd1fe43754b9a2cb99a4aa73fab65f6aee92929315773fed.

Contents
  package.sutra            the package: 5 Sutras, 3 connections, 0 schemas
  deployment-config.json   the deployment config: fill it in for the target environment
  documentation.html       what each Sutra does, step by step (also documentation.md)

Sutras
  Sample: AI tool search documents v1
  Sample: Add one document to knowledge v1
  Sample: Document assistant v1
  Sample: Document feed from a folder v1
  Sample: Document questions API v1

Secrets the target server needs in its vault
  none

Deploying
  1. Add the secrets:   sutra secret set NAME --from-env NAME --server https://prod:4800 --token ...
  2. Edit deployment-config.json for this environment (hosts, folders, users, secret names).
  3. Check:             sutra check release.zip --server https://prod:4800 --token ...
  4. Deploy:            sutra deploy release.zip --server https://prod:4800 --token ...
     or upload the zip in the Admin Console under Releases.
  Roll back:            sutra rollback --project "AI document assistant" --server ... --token ...
