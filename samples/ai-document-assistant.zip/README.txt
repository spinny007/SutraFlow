SutraFlow release AI document assistant 1.0.0

Sample project

Made 2026-10-19T04:09:08.749Z with SutraFlow 1.6.0. Checksum sha256:a88872fed8a3f9d04c4082d9de3f561da435e2cccc84fadfd7cd45d14c0dabf1.

Contents
  package.sutra            the package: 5 Sutras, 3 connections, 0 schemas
  deployment-config.json   the deployment config: fill it in for the target environment
  documentation.html       what each Sutra does, step by step (also documentation.md)

Sutras
  Sample: AI tool search documents v1
  Sample: Add one document to knowledge v1
  Sample: Document assistant v1
  Sample: Document feed from a folder v1
  Sample: Document questions API v1

Secrets the target server needs in its vault
  none

Deploying
  1. Add the secrets:   sutra secret set NAME --from-env NAME --server https://prod:4800 --token ...
  2. Edit deployment-config.json for this environment (hosts, folders, users, secret names).
  3. Check:             sutra check release.zip --server https://prod:4800 --token ...
  4. Deploy:            sutra deploy release.zip --server https://prod:4800 --token ...
     or upload the zip in the Admin Console under Releases.
  Roll back:            sutra rollback --project "AI document assistant" --server ... --token ...
