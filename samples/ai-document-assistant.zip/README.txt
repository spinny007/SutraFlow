SutraFlow release AI document assistant 1.0.0

Sample project

Made 2026-11-03T12:19:55.308Z with SutraFlow 2.1.5. Checksum sha256:edc69013759d5781f2db922d008a5466168b8b40fcf52ada28fef4bbbffc6a16.

Contents
  package.sutra            the package: 5 Sutras, 3 connections, 1 schemas
  deployment-config.json   the deployment config: fill it in for the target environment
  documentation.html       what each Sutra does, step by step (also documentation.md)

Sutras
  Sample: AI tool search documents v1
  Sample: Add one document to knowledge v1
  Sample: Document assistant v1
  Sample: Document feed from a folder v1
  Sample: Document questions API v1

Secrets the target server needs in its vault
  none

Deploying
  1. Add the secrets:   sutra secret set NAME --from-env NAME --server https://prod:4800 --token ...
  2. Edit deployment-config.json for this environment (hosts, folders, users, secret names).
  3. Check:             sutra check release.zip --server https://prod:4800 --token ...
  4. Deploy:            sutra deploy release.zip --server https://prod:4800 --token ...
     or upload the zip in the Admin Console under Releases.
  Roll back:            sutra rollback --project "AI document assistant" --server ... --token ...
